# GenAI Student Chatbot

This project is a GenAI-based chatbot designed to help students get answers related to academics, syllabus, dates, etc.

## Features
- Uses OpenAI GPT-3.5 API
- Simple Python code
- CLI based chatbot

## How to Run
1. Set your OpenAI API key in `main.py`
2. Run the file:
```bash
python main.py
```

## Author
K. Bharadwaj – 22BCE9328
