import openai

# Set your API key
openai.api_key = "your-api-key"

def ask_bot(prompt):
    response = openai.ChatCompletion.create(
      model="gpt-3.5-turbo",
      messages=[
        {"role": "system", "content": "You are a helpful assistant for students."},
        {"role": "user", "content": prompt}
      ]
    )
    return response['choices'][0]['message']['content']

if __name__ == "__main__":
    user_input = input("Ask your question: ")
    print("Bot says:", ask_bot(user_input))
